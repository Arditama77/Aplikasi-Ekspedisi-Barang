<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pengirim extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        cek_login();

        $this->load->model('Admin_model', 'admin');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = "Pengirim";
        $data['pengirim'] = $this->admin->get('pengirim');
        $this->template->load('templates/dashboard', 'pengirim/data', $data);
    }

    private function _validasi()
    {
        $this->form_validation->set_rules('nama_pengirim', 'Nama Pengirim', 'required|trim');
        $this->form_validation->set_rules('no_telp', 'Nomor Telepon', 'required|trim|numeric');
        $this->form_validation->set_rules('alamat', 'Alamat', 'required|trim');
    }

    public function add()
    {
        $this->_validasi();
        if ($this->form_validation->run() == false) {
            $data['title'] = "Pengirim";
            $this->template->load('templates/dashboard', 'pengirim/add', $data);
        } else {
            $input = $this->input->post(null, true);
            $save = $this->admin->insert('pengirim', $input);
            if ($save) {
                set_pesan('data berhasil disimpan.');
                redirect('pengirim');
            } else {
                set_pesan('data gagal disimpan', false);
                redirect('pengirim/add');
            }
        }
    }


    public function edit($getId)
    {
        $id = encode_php_tags($getId);
        $this->_validasi();

        if ($this->form_validation->run() == false) {
            $data['title'] = "Pengirim";
            $data['pengirim'] = $this->admin->get('pengirim', ['id_pengirim' => $id]);
            $this->template->load('templates/dashboard', 'pengirim/edit', $data);
        } else {
            $input = $this->input->post(null, true);
            $update = $this->admin->update('pengirim', 'id_pengirim', $id, $input);

            if ($update) {
                set_pesan('data berhasil diedit.');
                redirect('pengirim');
            } else {
                set_pesan('data gagal diedit.');
                redirect('pengirim/edit/' . $id);
            }
        }
    }

    public function delete($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->admin->delete('pengirim', 'id_pengirim', $id)) {
            set_pesan('data berhasil dihapus.');
        } else {
            set_pesan('data gagal dihapus.', false);
        }
        redirect('pengirim');
    }
}
